from cryptography.fernet import Fernet
from flask import Flask, render_template, request

app = Flask(__name__)

key = Fernet.generate_key()
cipher_suite = Fernet(key)

def chiffrement_symmetrique (message):
    data = bytes(message, 'utf-8')
    cipher_text = cipher_suite.encrypt(data)
    return cipher_text

def dechiffrement_symetrique (message):
    plain_text = cipher_suite.decrypt(message)
    return plain_text.decode()