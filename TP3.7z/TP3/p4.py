from flask import Flask, g
from cryptography.fernet import Fernet
import sqlite3

app = Flask(__name__)

DATABASE = "database.db"


def get_db():
    """Fonction pour obtenir une connexion à la base de données"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def get_cursor():
    """Fonction pour obtenir un curseur"""
    return get_db().cursor()

def close_connection(exception):
    """Ferme la connexion à la fin de chaque requête"""
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    """Initialise la base de données"""
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS chiffrement_symetriqueA (
        id INTEGER PRIMARY KEY,
        code BLOB, 
        message_code BLOB
    );
    ''')
    db.commit()


def chiffrement_symmetriqueA(message):
    init_db()
    key = Fernet.generate_key()
    cipher_suite = Fernet(key)
    data = bytes(message, 'utf-8')
    cipher_text = cipher_suite.encrypt(data)
    
    # Utilisez le curseur du thread actuel
    cursor = get_cursor()
    db = get_db()
    

    cursor.execute("SELECT MAX(id) FROM chiffrement_symetriqueA")
    result = cursor.fetchone()
    last_id = result[0] if result[0] is not None else 0  # Corriger ici - accéder au premier élément du tuple
    new_id = last_id + 1
    
    # Corrigé le nombre de paramètres dans la requête SQL
    cursor.execute("INSERT INTO chiffrement_symetriqueA (id, code, message_code) VALUES (?, ?, ?)", 
                  (new_id, key, cipher_text))
    db.commit()
    
    return message