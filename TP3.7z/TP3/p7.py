from flask import Flask, g
from cryptography.fernet import Fernet
import sqlite3
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA


app = Flask(__name__)

DATABASE = "database.db"



def chiffrement_asymetriqueD(message):
    # Utiliser la connexion du thread actuel
    db = sqlite3.connect(DATABASE)
    cursor  = db.cursor()
    
    
    cursor.execute("SELECT code FROM chiffrement_asymetriqueD WHERE id = 1")
    result = cursor.fetchone()
    if not result:
        return "Message non trouvé"
    
    cle_publique_bytes = result[0]
    cle_publique = RSA.import_key(cle_publique_bytes)
    cipher = PKCS1_OAEP.new(cle_publique)

    encrypteMsg = cipher.encrypt(message.encode())
    
    cursor.execute('SELECT EXISTS(SELECT 1 FROM chiffrement_asymetriqueD WHERE id=2 LIMIT 1)')
    exists = cursor.fetchone()
    if exists:
        cursor.execute('DELETE FROM chiffrement_asymetriqueD WHERE id=2;')
        db.commit()
    
    cursor.execute("INSERT INTO chiffrement_asymetriqueD (id, code) VALUES (?, ?)", 
                  (2, encrypteMsg))
    
    # Valider les modifications
    db.commit()