from flask import Flask, g
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from cryptography.hazmat.primitives import serialization
import sqlite3

app = Flask(__name__)

DATABASE = "database.db"


def get_db():
    """Fonction pour obtenir une connexion à la base de données"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def get_cursor():
    """Fonction pour obtenir un curseur"""
    return get_db().cursor()


def init_db():
    """Initialise la base de données"""
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS chiffrement_asymetriqueD (
        id INTEGER PRIMARY KEY,
        code BLOB
    );
    ''')
    db.commit()
    

def save_private_key(pk, filename):
    with open(filename, 'wb') as pem_out:
        pem_out.truncate(0)
        pem_out.write(pk)

def save_public_key(pk):
    cursor = get_cursor()
    db = get_db()
    
    cursor.execute('SELECT EXISTS(SELECT 1 FROM chiffrement_asymetriqueD WHERE id=1 LIMIT 1)')
    exists = cursor.fetchone()
    if exists:
        cursor.execute('DELETE FROM chiffrement_asymetriqueD;')
        db.commit()
        
    cursor.execute("INSERT INTO chiffrement_asymetriqueD (id, code) VALUES (?, ?)", 
                  (1, pk))
    db.commit()

def generer_cle():
    init_db()
    cle_rsa = RSA.generate(2048)
    cle_privee = cle_rsa.export_key()
    cle_publique = cle_rsa.publickey().export_key()
    save_public_key(cle_publique)
    save_private_key(cle_privee, "private_key_D.txt")
