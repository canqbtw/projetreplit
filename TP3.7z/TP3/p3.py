from flask import Flask, render_template, request
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

app = Flask(__name__)

cle_rsa = RSA.generate(2048)

cle_privee = PKCS1_OAEP.new(cle_rsa)
cle_publique = PKCS1_OAEP.new(cle_rsa.public_key())


def chiffrement_asymmetrique1 (message):
    encrypteMsg = cle_publique.encrypt(message.encode())
    return encrypteMsg

def dechiffrement_asymetrique1 (message):
    decryptedMsg = cle_privee.decrypt(message)
    return decryptedMsg.decode()