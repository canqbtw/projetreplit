from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from flask import Flask, g
from cryptography.fernet import Fernet
import sqlite3
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA


app = Flask(__name__)

DATABASE = "database.db"

def get_db():
    """Fonction pour obtenir une connexion à la base de données"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def get_cursor():
    """Fonction pour obtenir un curseur"""
    return get_db().cursor()


def load_key(filename):
    with open(filename, 'rb') as pem_in:
        pemlines = pem_in.read()
    return pemlines

def dechiffrement_asymetriqueD():
    db = get_db()
    cursor = get_cursor()
    cle_privee_bytes = load_key("private_key_D.txt")
    cle_privee = RSA.import_key(cle_privee_bytes)
    cipher = PKCS1_OAEP.new(cle_privee)
    
    cursor.execute("SELECT code FROM chiffrement_asymetriqueD WHERE id = 2")
    result = cursor.fetchone()
    if not result:
        return "Message non trouvé"
    message = result[0]
    message_dechiffre = cipher.decrypt(message)
    return message_dechiffre.decode()