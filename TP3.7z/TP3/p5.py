from flask import Flask, g
from cryptography.fernet import Fernet
import sqlite3

app = Flask(__name__)

DATABASE = "database.db"

def get_db():
    """Fonction pour obtenir une connexion à la base de données"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def get_cursor():
    """Fonction pour obtenir un curseur"""
    return get_db().cursor()



def dechiffrement_symetriqueB():
    # Utiliser la connexion du thread actuel
    db = get_db()
    cursor = get_cursor()
    
    cursor.execute("SELECT code, message_code FROM chiffrement_symetriqueA WHERE id = 1")
    result = cursor.fetchone()
    
    if not result:
        return "Message non trouvé"

    key = result[0]  # La clé stockée
    cipher_text = result[1]  # Le texte chiffré
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(cipher_text)
    
    cursor.execute("DELETE FROM chiffrement_symetriqueA WHERE id = 1")
    
    # Réindexer les autres lignes (décaler les IDs)
    cursor.execute("UPDATE chiffrement_symetriqueA SET id = id - 1 WHERE id > 1")
    
    # Valider les modifications
    db.commit()
    
    return decrypted_data.decode('utf-8')