from flask import Flask, render_template, request

app = Flask(__name__)

from p1  import chiffrement_cesar, dechiffrement_cesar
from p2 import chiffrement_symmetrique, dechiffrement_symetrique
from p3 import chiffrement_asymmetrique1, dechiffrement_asymetrique1
from p4 import chiffrement_symmetriqueA
from p5 import dechiffrement_symetriqueB
from p6 import generer_cle
from p7 import chiffrement_asymetriqueD
from p8 import dechiffrement_asymetriqueD
from p9 import cle_publique


@app.route("/", methods=["GET", "POST"])
def index():
    resultat = None

    if request.method == "POST":
        choix = request.form.get("choix")

        if choix == "1":  # Chiffrement César
            if "parm1" not in request.form:  # Si les paramètres ne sont pas encore saisis
                return render_template("saisie.html", choix=choix)
            else:
                # Récupérer les paramètres saisis
                parm1 = int(request.form["parm1"])
                parm2 = request.form["parm2"]

                # Chiffrement et déchiffrement
                message_chiffre = chiffrement_cesar(parm2, parm1)
                message_dechiffre = dechiffrement_cesar(message_chiffre, parm1)

                # Retourner le résultat formaté
                resultat = f"1: Texte original : {parm2} > Texte chiffré : {message_chiffre} > Texte déchiffré : {message_dechiffre}"
        if choix == "2":  # Chiffrement symetrique
            if "parm2" not in request.form:  # Si les paramètres ne sont pas encore saisis
                return render_template("saisie.html", choix=choix)
            else:
                # Récupérer les paramètres saisis
                parm2 = request.form["parm2"]

                # Chiffrement et déchiffrement
                message_chiffre = chiffrement_symmetrique(parm2)
                message_dechiffre = dechiffrement_symetrique(message_chiffre)

                # Retourner le résultat formaté
                resultat = f"2: Texte original : {parm2} > Texte chiffré : {message_chiffre} > Texte déchiffré : {message_dechiffre}"
        if choix == "3":  # Chiffrement symetrique
            if "parm2" not in request.form:  # Si les paramètres ne sont pas encore saisis
                return render_template("saisie.html", choix=choix)
            else:
                # Récupérer les paramètres saisis
                parm2 = request.form["parm2"]

                # Chiffrement et déchiffrement
                message_chiffre = chiffrement_asymmetrique1(parm2)
                message_dechiffre = dechiffrement_asymetrique1(message_chiffre)

                # Retourner le résultat formaté
                resultat = f"3: Texte original : {parm2} > Texte chiffré : {message_chiffre} > Texte déchiffré : {message_dechiffre}"
        if choix == "4":  # Chiffrement symetrique
            if "parm2" not in request.form:  # Si les paramètres ne sont pas encore saisis
                return render_template("saisie.html", choix=choix)
            else:
                # Récupérer les paramètres saisis
                parm2 = request.form["parm2"]

                # Chiffrement et déchiffrement
                message = chiffrement_symmetriqueA(parm2)

                # Retourner le résultat formaté
                resultat = f"4: Message envoyé par A à B : {message}"
        if choix == "5":  # Chiffrement symetrique
            message = dechiffrement_symetriqueB()

            # Retourner le résultat formaté
            resultat = f"5: Message recu par B de A : {message}"
        if choix == "6":  # Chiffrement symetrique
            generer_cle()

            # Retourner le résultat formaté
            resultat = f"6: Clé publique de D stockée dans la base de données. Clé privée de D sauvegardée dans 'private_key_D.txt"
        if choix == "7":  # Chiffrement symetrique
            if "parm2" not in request.form:  # Si les paramètres ne sont pas encore saisis
                return render_template("saisie.html", choix=choix)
            else:
                # Récupérer les paramètres saisis
                parm2 = request.form["parm2"]
                chiffrement_asymetriqueD(parm2)

            # Retourner le résultat formaté
            resultat = f"7: Message envoyé à D -> {parm2}"
        if choix == "8":  # Chiffrement symetrique
            message = dechiffrement_asymetriqueD()

            # Retourner le résultat formaté
            resultat = f"8: {message}"
        if choix == "9":  # Chiffrement symetrique
            cle = cle_publique()
            print(cle)
        


    # Afficher le menu avec le résultat (si disponible)
    return render_template("index.html", resultat=resultat)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
