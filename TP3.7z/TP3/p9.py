from flask import Flask, g
import sqlite3
from Crypto.PublicKey import RSA

app = Flask(__name__)

DATABASE = "database.db"

def get_db():
    """Fonction pour obtenir une connexion à la base de données"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def get_cursor():
    """Fonction pour obtenir un curseur"""
    return get_db().cursor()

def cle_publique():
    db = get_db()
    cursor = get_cursor()
    
    cursor.execute("SELECT code FROM chiffrement_asymetriqueD WHERE id = 1")
    result = cursor.fetchone()
    cle_publique = "Owner : C, Public Key:", result[0].decode()
    return cle_publique

