from flask import Flask, render_template, request

app = Flask(__name__)

# Fonction pour le chiffrement de César
def chiffrement_cesar(message, decalage):
    resultat = ""
    for caractere in message:
        if caractere.isalpha():  # Vérifie si c'est une lettre
            majuscule = caractere.isupper()
            code = ord(caractere.lower()) + decalage  # Décalage
            if code > ord('w'):
                code -= 26  # Retour au début de l'alphabet
            if code < ord('a'):
                code += 26  # Retour à la fin de l'alphabet
            nouveau_caractere = chr(code)
            resultat += nouveau_caractere.upper() if majuscule else nouveau_caractere
        elif caractere.isdigit():
            code = ord(str(caractere)) + decalage
            if code > ord('9'):
                code-= 10
            if code < ord('0'):
                code+=10
            nouveau_caractere = chr(code)
            resultat += nouveau_caractere
        else:
            resultat += caractere  # Conserve les espaces et la ponctuation
    return resultat


# Fonction pour le déchiffrement de César
def dechiffrement_cesar(message, decalage):
    return chiffrement_cesar(message, -decalage)  # Décaler dans l'autre sens